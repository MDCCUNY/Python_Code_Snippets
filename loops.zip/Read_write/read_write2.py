my_file = open("dna.txt")
my_dna = my_file.read() # .rstrip()
dna_length = len(my_dna)

print("Sequence is " + my_dna + " and length is " + str(dna_length))
