#open the input file
file = open("DNA.txt")

#open the output file
output= open("trimmed.txt", "w")

# go through the input file one line at a time
for dna in file:

    # get length of file
    last_character_pos = len(dna)

    # get the substring from the 15th character to the end
    trimmed_dna = dna[14:last_character_pos]

    # print out the trimmed sequence
    output.write(trimmed_dna)

    # print out the length to the screen
    print("processed sequence with length " + str(len(trimmed_dna)))

# close the output file
output.close()
