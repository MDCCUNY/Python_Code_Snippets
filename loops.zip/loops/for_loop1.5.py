for number in range(6): # range is a built in function that prints a list of numbers
    print(number)

print("/n")

for number in range(0, 7): # This function can hold more than one argument
    print(number)

print("\n")

for number in range(2, 14, 4) # the third argument is considered the step size
    print(number)
