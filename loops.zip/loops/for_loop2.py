# Definition of a Data Structure: The organization of data and the access method to that data.
# List: A list is similar to an array(C++, Java, etc.). A list holds items called elements. A list can hold multiple items and to access the elements, you must use its index.

food = ["cake", "pizza", "ham", "chicken"]

#In c++: string food[4] = {"cake", "pizza", "ham", "chicken"};
#Similar to C++, the first index in a list is 0, so if you want to print "cake"
#you do print(food[0])

for i in food:
    print(i)

