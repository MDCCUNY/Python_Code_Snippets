# A data structure is the organization of data and the access method to that data

# A list is a data structure that can hold many pieces of information at the same time
# and allows our programs to process multiple pieces of data.

# A list is similar to an array

# name is the name of the list we want to process
# i is the name we want to use for the current element each time round the loop
# Each time the loop loops, i changes to a new value in the list.

name = "Frank" # list equivalent: name = ['F', 'r', 'a', 'n', 'k']
# name = ['F', 'r', 'a', 'n', 'k']

for i in name:
 print(i)

