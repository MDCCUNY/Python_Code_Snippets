# There are no do-while loops in python

num = 10;

while(num <= 100):
    print(num)
    num = num + 10

