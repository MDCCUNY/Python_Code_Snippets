my_file = open("dna.txt") # Open is the function used to open the file object
file_contents = my_file.read() # We use the .read() method to read the contents
                               # of the file.
                               # Try without a file object or passing a var to my_file
print(file_contents)           # Prints the files contents.
