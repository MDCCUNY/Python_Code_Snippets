# open() can contain two arguments, the file object and ...
# r - read : Used by default, allows you to read a file
# w - write : If a file exists it will be overwritten but if it doesn't
# exist, it will be created.
# a - append: Similar to w but doesn't overwrite an existing file.

my_file = open("out.txt", "w")
my_file.write("Hello world! My name is Frank!") # .write() allows you to write to the file.

my_file = open("out.txt", "a")
my_file.write(" Goodbye!")

my_file = open("out.txt", "r")
file_contents = my_file.read()

print(file_contents)
my_file.close() # Closes the file
